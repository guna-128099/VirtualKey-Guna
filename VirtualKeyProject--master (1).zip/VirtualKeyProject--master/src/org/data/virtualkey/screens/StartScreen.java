package org.data.virtualkey.screens;

public interface StartScreen {
	    public void show();

	    public void goToOptions(int option);
	    
	    public void getInput();
}
